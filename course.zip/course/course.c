/**
 * @file course.c
 * @author Nathan Raposo (raposn1@mcmaster.ca)
 * @date 2022-04-12
 * @brief Defines functions in the course library.
 */
#include "course.h"
#include <stdlib.h>
#include <stdio.h>

/**
 * Adds a student to the list of students enrolled in the course.
 * 
 * @param course The course that a student is being enrolled in.
 * @param student The student being enrolled in the course.
 * @return nothing
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}

/**
 * Prints the course name, course code, the number of students enrolled
 * in the course, and the names, ids, and average grades of each student.
 * 
 * @param course The course whose details are being printed.
 * @return nothing
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
 * Returns the student in a given course with the highest average. Returns NULL
 * if there are no students enrolled in the course.
 * 
 * @param course The given course in which the top student is being determined.
 * @return student
 */
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/**
 * Returns all of the students in a given course who have an average grade
 * of at least 50 as a struct.
 * 
 * @param course The given course that is being looked at.
 * @param total_passing The number of students who have an average grade
 *                      of at least 50.
 * @return student
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  passing = calloc(count, sizeof(Student));

  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}