/**
 * @file course.h
 * @author Nathan Raposo (raposn1@mcmaster.ca)
 * @date 2022-04-12
 * @brief Library for managing courses, including course type
 *        definition and course functions.
 */
#include "student.h"
#include <stdbool.h>
 
typedef struct _course 
{
  char name[100]; /**< Course name */
  char code[10]; /**< Course code */
  Student *students; /**< List of students enrolled in the course */
  int total_students; /**< Number of students in the course */
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


