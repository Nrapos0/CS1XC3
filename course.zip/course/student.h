/**
 * @file student.h
 * @author Nathan Raposo (raposn1@mcmaster.ca)
 * @date 2022-04-12
 * @brief Library for managing students, including student type
 *        definition and student functions.
 */ 

/**
 * Defines student type which stores a student's name, id, and grades.
 */
typedef struct _student 
{ 
  char first_name[50]; /**< Student's first name */
  char last_name[50]; /**< Student's last name */
  char id[11]; /**< Student's id */
  double *grades; /**< Student's grades */
  int num_grades; /**< Number of grades a student has */
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
