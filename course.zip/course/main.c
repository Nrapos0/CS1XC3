/**
 * @file main.c
 * @author Nathan Raposo (raposn1@mcmaster.ca)
 * @date 2022-04-12
 * @brief Tests the functions in the "course" and "student" libraries.
 */
#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

int main()
{
  srand((unsigned) time(NULL));
/**
 * Defines the course MATH 101, Basics of Mathematics.
 */
  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

/**
 * Enrolls 20 randomly generated students in MATH 101.
 */
  for (int i = 0; i < 20; i++)
    enroll_student(MATH101, generate_random_student(8));
  
  print_course(MATH101);

/**
 * Finds and prints the top student in MATH 101.
 */
  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);

/**
 * Determines which students are passing MATH 101 and prints their names, ids, and grades.
 */
  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}